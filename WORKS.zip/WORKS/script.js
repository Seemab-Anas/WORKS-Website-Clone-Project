const scroll = new LocomotiveScroll({
    el: document.querySelector('#main'),
    smooth: true
});




const rows = document.querySelectorAll('#page2 .row');
const page2 = document.getElementById('page2');

rows.forEach(function(row){
    row.addEventListener('mouseenter', function() {
        const bgImage = row.getAttribute('data-bg');
        page2.style.backgroundImage = `url('./assets/${bgImage}')`;
    });
});


const footimg = document.querySelector(".footimg")

footimg.addEventListener("click",()=>{
    scroll.scrollTo(0);
})


let tl=gsap.timeline()
tl.to("#yellow",{
    top:"-100%",
    duration:0.8,
    ease:"expo.out"
})
tl.to("#loader h1",{
    color:"black",
    duration:0.1
})
tl.to("#loader video",{
    top:"-100%",
    opacity:0
})
tl.to("#black",{
    top:"-100%",
    duration:0.1
})
tl.to("#loader",{
    delay:-0.5,
    top:"-100%",
    display:"none"

})